#!/bin/sh
/usr/bin/test -e /host/ecscontainer && echo "checkecsfile=true"
